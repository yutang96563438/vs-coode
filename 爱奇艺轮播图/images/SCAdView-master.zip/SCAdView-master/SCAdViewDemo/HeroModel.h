//
//  HeroModel.h
//  SCAdViewDemo
//
//  Created by 陈世翰 on 17/2/8.
//  Copyright © 2017年 Coder Chan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HeroModel : NSObject
/**
 *   图片名称
 */
@property (nonatomic,strong)NSString * imageName;
/**
 *   介绍
 */
@property (nonatomic,strong)NSString *introduction;
@end
